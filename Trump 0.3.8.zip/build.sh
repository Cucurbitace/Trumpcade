#/bin/bash
zip -r -X build.zip .
