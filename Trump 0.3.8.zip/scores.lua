local scores = {
	{ name = "Donald", value = 1500000 },
	{ name = "Invaka", value = 1000000 },
	{ name = "Stevie B.", value = 900000 },
	{ name = "Big Daddy V.", value = 700000 },
	{ name = "Jared", value = 600000 },
	{ name = "Melania", value = 5 }
}
return scores