function love.conf(t)
	t.window.title = "Trump"
	t.identity = "Trump"
	t.version = "0.10.0"
	t.window.display = 1
	t.window.width = 224
	t.window.height = 320
	t.console = false
	--t.window.icon = "icon.png"
	t.window.vsync = true
end