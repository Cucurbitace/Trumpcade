-- flag is 28*19
local flag = {}
function flag:update( dt )
	-- body
end
function flag:draw()

end
return flag