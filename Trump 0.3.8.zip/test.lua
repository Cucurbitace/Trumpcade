local test = {
	
}

function test:update( dt )

end
function test:draw()
	
end
function test:keypressed( key )

end
return test